## mathjax-support-for-mkdp

![screenshot](https://cloud.githubusercontent.com/assets/5492542/20455946/275dc74c-aea3-11e6-96f8-0d1a47e50f95.png)

typesetting math

> MathJax support for [markdown-preview.vim](https://github.com/iamcco/markdown-preview.vim) plugin

**Install**

plug-vim:

```
Plug 'iamcco/mathjax-support-for-mkdp'
Plug 'iamcco/markdown-preview.vim'
```
> have to use with markdown-preview.vim
